Clockwork is a puzzle game about manipulating time.

Interacting with ingame elements will adjust the flow of time. Learn the rules of the world and use them to your advantage in order to progress.

Up Arrow Key -- Jump
Left and Right Arrow Keys -- Walk
Down -- Enter Door; Use Switches