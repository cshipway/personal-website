This is basically just a tech demo. I learned a lot about networking code doing this, though admittedly it's still somewhat unreliable.

Start the server software first. Clients can then connect to the server, and users can interact with each other.

WASD
W -- Jump
A, D -- Move Left and Right
S -- Use Doors

Mouse
Left Click -- Select a unit. (Neutral/Ally. Use this for positive actions, such as healing a friend.)
Right Click -- Select a unit. (Enemy. Use this for aggressive actions, like attacking.)

Number Keys.
1 -- Use Hotbar Slot 1 (Attack with Weapon)
2 -- Use Hotbar Slot 2 (Heal Selected Unit)
3 -- Use Hotbar Slot 3 (Freeze Selected Unit)

Enter -- Chat.
Some chat console commands...
/hp x. Set current HP to value x.
/mp x. Set current MP to value x.
/maxhp x. Set max HP to value x.
/maxmp x. Set max MP to value x.
/roomid. Returns the ID of the current room.
/hide. Hides the chat window. Type again to undo this.
/die. Instantly kills your character.
/hat x. Changes your hat based on value x.
   -0: No Hat
   -1: Top Hat
   -2: Wizard Hat
   -3: Knight's Helm
   -4: Happy Mask
/weapon x. Changes your weapon based on value x.
   -0: Hammer
   -1: Pistol